
export default {
    secret: '86855935c17611fc5a5a03cf8f302a79dba483f3',
    expiresIn: '5d',
};