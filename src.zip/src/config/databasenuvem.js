


module.exports = {
    
    dialect: 'postgres',
    url: 'postgresql://postgres:CZKkbzaJRRaBPjpJnulLbrxIThDhFpkx@maglev.proxy.rlwy.net:59335/railway',

    define: {
        timestamps: true,
        underscored: true,
        underscoredAll: true,
    },


};


// // configuração do stripe
// STRIPE_SECRET_KEY='sk_test_51RHbMhQRFA5bTw4XQeuFsn3M70AbuRrkUEbBg9upBgUNPijaVBxxDXXgkydzkDs74k7xp2sf2omKBu23xluOHPPc00wHyqmuDa'