module.exports = {
  async up(queryInterface) {
    const tableDefinition = await queryInterface.describeTable('Products');

    if (tableDefinition.description) {
      await queryInterface.removeColumn('Products', 'description');
    } else {
      console.log('A coluna "description" já não existe em "Products".');
    }
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.addColumn('Products', 'description', {
      type: Sequelize.STRING,
      allowNull: true,
    });
  }
};
